<h1>Sorteador aleatorio</h1>

faça uma lista de amigos e descubra quem ira bancar o proximo churrasco.

DEMO: https://maudev1.github.io/sorteadorAleatorio/
